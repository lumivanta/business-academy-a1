# Business Academy A1 — GitHub Pages edition

This is a static website. It is ready to publish from the root of a GitHub repository using GitHub Pages.

## Publish
1. Create a **public** GitHub repository named `business-academy-a1`.
2. Extract this ZIP on your device.
3. Upload the **contents** of the `business-academy-a1` folder to the repository root. The repository root must contain `index.html`, `404.html`, `assets/`, and `courses/`.
4. Open the repository → **Settings** → **Pages**.
5. Under **Build and deployment**, select **Deploy from a branch**.
6. Choose branch **main** and folder **/(root)**, then click **Save**.
7. Wait for the Pages deployment to finish. The expected address for the account `lumivanta` and this repository name is `https://lumivanta.github.io/business-academy-a1/`.

## Important
- This project uses relative links and is configured for a project site at `/business-academy-a1/`.
- Google Fonts are optional enhancements; system serif/sans-serif fallbacks remain available if external font loading is blocked.
- The course pages are introductory outlines, not completed courses or accredited qualifications.
- There is no user login, database, secure assessment engine, or verified certificate issuance in this static version.
- External European academic institution links are independent references, not partners, sponsors or endorsers.
