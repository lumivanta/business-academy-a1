(() => {
  'use strict';
  const $ = (selector) => document.querySelector(selector);
  const config = window.BA1_CONFIG || {};
  const courses = window.BA1_COURSES || [];
  const keyReady = Boolean(config.supabasePublishableKey && config.supabasePublishableKey !== 'PASTE_YOUR_SB_PUBLISHABLE_KEY_HERE');
  const supabase = (keyReady && window.supabase?.createClient)
    ? window.supabase.createClient(config.supabaseUrl, config.supabasePublishableKey)
    : null;

  let currentUser = null;
  let activeCourse = null;
  let activeUnitIndex = 0;
  let completedLessons = new Set();
  let certificates = [];
  let authMode = 'signin';
  let toastTimer;

  const escapeHTML = (value) => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const getCourse = (id) => courses.find(course => course.id === id);
  const allLessons = () => courses.flatMap(course => course.units.map(unit => unit.id));
  const isComplete = (lessonId) => completedLessons.has(lessonId);

  function toast(message) {
    const node = $('#toast');
    node.textContent = message;
    node.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => node.classList.remove('show'), 3200);
  }

  function updateAuthUI() {
    $('#authNav').textContent = currentUser ? 'My account' : 'Sign in';
    $('#dashboardNav').hidden = !currentUser;
    $('#heroAuth').textContent = currentUser ? 'Open my dashboard' : 'Student account';
  }

  function renderProgrammes() {
    $('#programGrid').innerHTML = courses.map(course => `
      <article class="program-card" data-course="${escapeHTML(course.id)}" tabindex="0" role="button" aria-label="Open ${escapeHTML(course.title)}">
        <div class="program-no">PROGRAMME ${escapeHTML(course.number)} · ${course.units.length} UNITS</div>
        <h3>${escapeHTML(course.title)}</h3>
        <p>${escapeHTML(course.short)}</p>
        <div class="program-card-footer"><span>Explore programme</span><span>↗</span></div>
      </article>`).join('');

    $('#programGrid').querySelectorAll('[data-course]').forEach(card => {
      card.addEventListener('click', () => navigateToCourse(card.dataset.course));
      card.addEventListener('keydown', event => {
        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); navigateToCourse(card.dataset.course); }
      });
    });
  }

  function showView(which) {
    $('#homeView').classList.toggle('view-hidden', which !== 'home');
    $('#courseView').classList.toggle('view-hidden', which !== 'course');
    $('#dashboardView').classList.toggle('view-hidden', which !== 'dashboard');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function navigateToCourse(id) {
    const course = getCourse(id);
    if (!course) return;
    activeCourse = course;
    activeUnitIndex = 0;
    history.replaceState(null, '', `#program/${id}`);
    showView('course');
    $('#courseNumber').textContent = `PROGRAMME ${course.number}`;
    $('#courseTitle').textContent = course.title;
    $('#courseShort').textContent = course.short;
    $('#courseLevel').textContent = course.level;
    await loadProgress();
    renderUnitNavigation();
    renderLesson();
    updateCourseProgress();
    closeMobileNav();
  }

  function renderUnitNavigation() {
    if (!activeCourse) return;
    $('#unitList').innerHTML = activeCourse.units.map((unit, index) => `
      <button class="unit-button ${index === activeUnitIndex ? 'active' : ''}" data-unit-index="${index}" type="button">
        <span class="unit-index">${String(index + 1).padStart(2, '0')}</span>
        <span><strong>${escapeHTML(unit.title)}</strong><small>${isComplete(unit.id) ? 'Completed' : 'Lesson · self-paced'}</small></span>
        ${isComplete(unit.id) ? '<span class="done-check" aria-label="Completed">✓</span>' : ''}
      </button>`).join('');
    $('#unitList').querySelectorAll('[data-unit-index]').forEach(button => {
      button.addEventListener('click', () => {
        activeUnitIndex = Number(button.dataset.unitIndex);
        renderUnitNavigation();
        renderLesson();
      });
    });
  }

  function renderLesson() {
    if (!activeCourse) return;
    const unit = activeCourse.units[activeUnitIndex];
    if (!unit) return;
    const completed = isComplete(unit.id);
    const lessonSections = unit.lessons.map((lesson, index) => `
      <section class="lesson-section">
        <h3>${index + 1}. ${escapeHTML(lesson[0])}</h3>
        <p>${escapeHTML(lesson[1])}</p>
      </section>`).join('');
    const visualSteps = unit.visual.steps.map((step, index) => `${index ? '<span class="visual-arrow" aria-hidden="true">→</span>' : ''}<div class="visual-step">${escapeHTML(step)}</div>`).join('');
    const references = unit.references.map(ref => `<a href="${escapeHTML(ref[1])}" target="_blank" rel="noopener noreferrer">${escapeHTML(ref[0])} ↗</a>`).join('');
    const reflections = unit.reflection.map(item => `<li>${escapeHTML(item)}</li>`).join('');

    $('#lessonPanel').innerHTML = `
      <div class="lesson-kicker">${escapeHTML(activeCourse.title)} · Unit ${activeUnitIndex + 1} of 4</div>
      <h2 class="lesson-title">${escapeHTML(unit.title)}</h2>
      <div class="lesson-question">${escapeHTML(unit.question)}</div>
      <p class="lesson-intro">${escapeHTML(unit.intro)}</p>
      ${lessonSections}
      <div class="visual-card"><h3>Visual framework · ${escapeHTML(unit.visual.title)}</h3><div class="visual-flow">${visualSteps}</div></div>
      <div class="case-card"><h3>Applied case</h3><p>${escapeHTML(unit.case)}</p></div>
      <div class="caveat-card"><h3>Critical perspective</h3><p>${escapeHTML(unit.caveat)}</p></div>
      <div class="reflection-card"><h3>Questions for reflection</h3><ul>${reflections}</ul></div>
      <div class="reference-list"><h3>Academic and further reading</h3>${references}</div>
      <div class="lesson-actions"><p>${completed ? 'This unit is recorded as complete in your account.' : 'Finish the reading, then mark this unit complete to save your progress.'}</p><button class="complete-button ${completed ? 'done' : ''}" id="completeLesson">${completed ? '✓ Unit completed' : 'Mark unit as complete'}</button></div>
      ${!currentUser ? '<p class="locked-hint">Sign in is required to save completion. All lesson content remains freely accessible.</p>' : ''}`;

    $('#completeLesson').addEventListener('click', () => markLessonComplete(unit));
  }

  function updateCourseProgress() {
    if (!activeCourse) return;
    const count = activeCourse.units.filter(unit => isComplete(unit.id)).length;
    $('#courseProgressText').textContent = `${count} / 4`;
    $('#courseProgressBar').style.width = `${count * 25}%`;
    $('#courseProgressHint').textContent = !currentUser
      ? 'Sign in to save your learning progress.'
      : count === 4 ? 'Programme completed. Your certificate is available in My learning.' : `${4 - count} unit${4 - count === 1 ? '' : 's'} remaining in this programme.`;
  }

  async function loadProgress() {
    if (!supabase || !currentUser) {
      completedLessons = new Set();
      return;
    }
    const { data, error } = await supabase.from('lesson_progress').select('lesson_id').eq('user_id', currentUser.id);
    if (error) {
      console.error('Progress load failed:', error);
      toast('Could not load saved progress. Check the Supabase setup.');
      return;
    }
    completedLessons = new Set((data || []).map(row => row.lesson_id));
  }

  async function markLessonComplete(unit) {
    if (!currentUser) {
      showAuth('signin');
      $('#authMessage').textContent = 'Sign in or create a free account to save completed units.';
      return;
    }
    if (!supabase) {
      toast('Student accounts are not configured yet. Add the Publishable key first.');
      return;
    }
    const { error } = await supabase.from('lesson_progress').upsert({
      user_id: currentUser.id,
      program_id: activeCourse.id,
      lesson_id: unit.id,
      completed_at: new Date().toISOString()
    }, { onConflict: 'user_id,lesson_id' });
    if (error) {
      console.error('Progress save failed:', error);
      toast(`Could not save progress: ${error.message}`);
      return;
    }
    completedLessons.add(unit.id);
    renderUnitNavigation();
    renderLesson();
    updateCourseProgress();
    toast('Unit completion saved to your account.');

    const completedCount = activeCourse.units.filter(item => isComplete(item.id)).length;
    if (completedCount === activeCourse.units.length) await issueCertificate(activeCourse);
  }

  async function issueCertificate(course) {
    if (!supabase || !currentUser) return;
    const { data: existing, error: checkError } = await supabase.from('certificates').select('*').eq('user_id', currentUser.id).eq('program_id', course.id).maybeSingle();
    if (checkError) {
      console.error('Certificate lookup failed:', checkError);
      toast('All units are complete. Certificate lookup needs attention in Supabase.');
      return;
    }
    if (existing) {
      await loadCertificates();
      toast('Programme already completed. Your saved certificate is in My learning.');
      return;
    }
    if (!window.jspdf?.jsPDF) {
      toast('The PDF library could not load. Check your connection and retry from My learning.');
      return;
    }

    const issuedAt = new Date();
    const shortId = (window.crypto?.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`).replace(/-/g, '').slice(0, 10).toUpperCase();
    const certificateNumber = `BA1-${issuedAt.getFullYear()}-${shortId}`;
    const filePath = `${currentUser.id}/${course.id}/${certificateNumber}.pdf`;
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    pdf.setFillColor(16, 31, 53); pdf.rect(0, 0, pageWidth, pageHeight, 'F');
    pdf.setDrawColor(198, 166, 107); pdf.setLineWidth(1.1); pdf.rect(11, 11, pageWidth - 22, pageHeight - 22);
    pdf.setDrawColor(234, 215, 175); pdf.setLineWidth(.25); pdf.rect(15, 15, pageWidth - 30, pageHeight - 30);
    pdf.setTextColor(234, 215, 175); pdf.setFont('times', 'normal'); pdf.setFontSize(15); pdf.text('BUSINESS ACADEMY A1', pageWidth / 2, 38, { align: 'center' });
    pdf.setTextColor(255, 255, 255); pdf.setFont('times', 'bold'); pdf.setFontSize(31); pdf.text('CERTIFICATE OF COMPLETION', pageWidth / 2, 63, { align: 'center' });
    pdf.setFont('times', 'normal'); pdf.setFontSize(14); pdf.setTextColor(210, 218, 227); pdf.text('This certificate is presented to', pageWidth / 2, 86, { align: 'center' });
    pdf.setFont('times', 'bold'); pdf.setFontSize(23); pdf.setTextColor(234, 215, 175); pdf.text(currentUser.email || 'Learner', pageWidth / 2, 103, { align: 'center' });
    pdf.setFont('times', 'normal'); pdf.setFontSize(13); pdf.setTextColor(210, 218, 227); pdf.text('for completing the learning programme', pageWidth / 2, 121, { align: 'center' });
    pdf.setFont('times', 'bold'); pdf.setFontSize(22); pdf.setTextColor(255, 255, 255); pdf.text(course.title, pageWidth / 2, 139, { align: 'center' });
    pdf.setFont('times', 'normal'); pdf.setFontSize(11); pdf.setTextColor(210, 218, 227); pdf.text('Four learning units completed · Self-paced academic learning', pageWidth / 2, 154, { align: 'center' });
    pdf.setDrawColor(198, 166, 107); pdf.line(42, 171, 92, 171); pdf.line(pageWidth - 92, 171, pageWidth - 42, 171);
    pdf.setFontSize(9); pdf.setTextColor(234, 215, 175); pdf.text(`Issued ${issuedAt.toLocaleDateString('en-GB')}`, 48, 181, { align: 'center' });
    pdf.text(`Certificate no. ${certificateNumber}`, pageWidth - 48, 181, { align: 'center' });
    pdf.setFontSize(8); pdf.setTextColor(170, 183, 198); pdf.text('Issued by Business Academy A1. This is an educational completion certificate, not a university degree or professional accreditation.', pageWidth / 2, 194, { align: 'center' });
    const blob = pdf.output('blob');

    const { error: uploadError } = await supabase.storage.from('ba1-certificates').upload(filePath, blob, { contentType: 'application/pdf', upsert: false });
    if (uploadError) {
      console.error('Certificate upload failed:', uploadError);
      toast(`PDF created but could not be saved: ${uploadError.message}`);
      return;
    }
    const { error: insertError } = await supabase.rpc('issue_ba1_certificate', {
      p_program_id: course.id,
      p_certificate_number: certificateNumber,
      p_file_path: filePath
    });
    if (insertError) {
      await supabase.storage.from('ba1-certificates').remove([filePath]);
      console.error('Certificate record insert failed:', insertError);
      toast(`The PDF was generated but could not be issued: ${insertError.message}`);
      return;
    }
    pdf.save(`${course.id}-certificate.pdf`);
    await loadCertificates();
    renderDashboard();
    toast('Congratulations. Your completion certificate has been saved to your account.');
  }

  function showAuth(mode = 'signin') {
    setAuthMode(mode);
    $('#authMessage').textContent = supabase ? '' : 'Account connection is not active yet. Add the Supabase Publishable key in assets/js/config.js and run the database setup script.';
    $('#authModal').hidden = false;
    $('#authEmail').focus();
  }

  function closeAuth() { $('#authModal').hidden = true; }

  function setAuthMode(mode) {
    authMode = mode;
    document.querySelectorAll('.auth-tabs button').forEach(button => button.classList.toggle('active', button.dataset.mode === mode));
    $('#authTitle').textContent = mode === 'signup' ? 'Create your free account' : 'Sign in to your learning space';
    $('#authSubmit').textContent = mode === 'signup' ? 'Create account' : 'Sign in';
    $('#authPassword').autocomplete = mode === 'signup' ? 'new-password' : 'current-password';
    $('#authMessage').textContent = '';
  }

  async function handleAuth(event) {
    event.preventDefault();
    if (!supabase) {
      $('#authMessage').textContent = 'Setup required: add your Publishable key in assets/js/config.js, then run supabase/schema.sql in the Supabase SQL Editor.';
      return;
    }
    const email = $('#authEmail').value.trim();
    const password = $('#authPassword').value;
    const button = $('#authSubmit');
    button.disabled = true;
    button.textContent = authMode === 'signup' ? 'Creating account…' : 'Signing in…';
    let result;
    if (authMode === 'signup') {
      result = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin + window.location.pathname } });
    } else {
      result = await supabase.auth.signInWithPassword({ email, password });
    }
    button.disabled = false;
    button.textContent = authMode === 'signup' ? 'Create account' : 'Sign in';
    if (result.error) {
      $('#authMessage').textContent = result.error.message;
      return;
    }
    if (authMode === 'signup' && !result.data.session) {
      $('#authMessage').textContent = 'Account created. Check your email for the confirmation link, then return here to sign in.';
      return;
    }
    currentUser = result.data.user || result.data.session?.user || null;
    closeAuth();
    updateAuthUI();
    await loadProgress();
    await loadCertificates();
    if (activeCourse) {
      renderUnitNavigation(); renderLesson(); updateCourseProgress();
    }
    toast(authMode === 'signup' ? 'Your student account is ready.' : 'You are signed in.');
    if (window.location.hash === '#dashboard' || authMode === 'signup') await openDashboard();
  }

  async function signOut() {
    if (supabase) {
      const { error } = await supabase.auth.signOut();
      if (error) { toast(`Sign out failed: ${error.message}`); return; }
    }
    currentUser = null;
    completedLessons = new Set();
    certificates = [];
    updateAuthUI();
    if (activeCourse) { renderUnitNavigation(); renderLesson(); updateCourseProgress(); }
    showView('home');
    history.replaceState(null, '', '#home');
    toast('You have signed out.');
  }

  async function loadCertificates() {
    if (!supabase || !currentUser) { certificates = []; return; }
    const { data, error } = await supabase.from('certificates').select('id,program_id,certificate_number,file_path,issued_at').eq('user_id', currentUser.id).order('issued_at', { ascending: false });
    if (error) { console.error('Certificate list failed:', error); return; }
    certificates = data || [];
  }

  async function openDashboard() {
    if (!currentUser) { showAuth('signin'); return; }
    showView('dashboard');
    $('#dashboardEmail').textContent = currentUser.email || '';
    await loadProgress();
    await loadCertificates();
    renderDashboard();
    history.replaceState(null, '', '#dashboard');
  }

  function renderDashboard() {
    $('#dashboardEmail').textContent = currentUser?.email || '';
    $('#dashboardGrid').innerHTML = courses.map(course => {
      const done = course.units.filter(unit => isComplete(unit.id)).length;
      return `<article class="dashboard-card"><h3>${escapeHTML(course.title)}</h3><div class="progress-label"><span>Units completed</span><strong>${done} / 4</strong></div><div class="progress-track"><span style="width:${done * 25}%"></span></div><p>${done === 4 ? 'Programme complete' : `${4 - done} unit${4 - done === 1 ? '' : 's'} remaining`}</p><button class="btn btn-small btn-outline" data-open-course="${escapeHTML(course.id)}">${done === 4 ? 'Review programme' : 'Continue learning'}</button></article>`;
    }).join('');
    $('#dashboardGrid').querySelectorAll('[data-open-course]').forEach(button => button.addEventListener('click', () => navigateToCourse(button.dataset.openCourse)));

    if (!certificates.length) {
      $('#certificateList').innerHTML = '<p class="muted">No certificates yet. Complete all four units of a programme to receive a certificate.</p>';
      return;
    }
    $('#certificateList').innerHTML = certificates.map(certificate => {
      const course = getCourse(certificate.program_id);
      return `<div class="certificate-item"><div><strong>${escapeHTML(course?.title || certificate.program_id)}</strong><small>${escapeHTML(certificate.certificate_number)} · ${new Date(certificate.issued_at).toLocaleDateString('en-GB')}</small></div><button type="button" data-certificate-path="${escapeHTML(certificate.file_path)}">View / download PDF</button></div>`;
    }).join('');
    $('#certificateList').querySelectorAll('[data-certificate-path]').forEach(button => button.addEventListener('click', () => openCertificate(button.dataset.certificatePath)));
  }

  async function openCertificate(filePath) {
    const { data, error } = await supabase.storage.from('ba1-certificates').createSignedUrl(filePath, 180);
    if (error) { toast(`Could not open certificate: ${error.message}`); return; }
    window.open(data.signedUrl, '_blank', 'noopener');
  }

  function routeFromHash() {
    const hash = window.location.hash || '#home';
    if (hash.startsWith('#program/')) {
      navigateToCourse(hash.slice('#program/'.length));
    } else if (hash === '#dashboard') {
      if (currentUser) openDashboard(); else { showView('home'); showAuth('signin'); }
    } else if (hash.startsWith('#home') || hash === '#') {
      showView('home');
    } else {
      // Keep ordinary home-page anchor navigation (for example #programmes) intact.
      $('#homeView').classList.remove('view-hidden');
      $('#courseView').classList.add('view-hidden');
      $('#dashboardView').classList.add('view-hidden');
    }
  }

  function closeMobileNav() { $('#navigation').classList.remove('open'); $('#mobileMenu').setAttribute('aria-expanded', 'false'); }

  function bindEvents() {
    $('#authNav').addEventListener('click', () => currentUser ? openDashboard() : showAuth('signin'));
    $('#heroAuth').addEventListener('click', () => currentUser ? openDashboard() : showAuth('signup'));
    $('#dashboardNav').addEventListener('click', openDashboard);
    $('#backToHome').addEventListener('click', () => { history.replaceState(null, '', '#programmes'); showView('home'); $('#programmes').scrollIntoView({behavior:'smooth'}); });
    $('#closeAuth').addEventListener('click', closeAuth);
    $('#authModal').addEventListener('click', event => { if (event.target === $('#authModal')) closeAuth(); });
    $('#authForm').addEventListener('submit', handleAuth);
    document.querySelectorAll('.auth-tabs button').forEach(button => button.addEventListener('click', () => setAuthMode(button.dataset.mode)));
    $('#signOut').addEventListener('click', signOut);
    $('#mobileMenu').addEventListener('click', () => {
      const open = $('#navigation').classList.toggle('open');
      $('#mobileMenu').setAttribute('aria-expanded', String(open));
    });
    $('#navigation').querySelectorAll('a').forEach(link => link.addEventListener('click', closeMobileNav));
    window.addEventListener('hashchange', routeFromHash);
    $('#year').textContent = new Date().getFullYear();
  }

  async function init() {
    renderProgrammes();
    bindEvents();
    updateAuthUI();
    if (supabase) {
      const { data } = await supabase.auth.getSession();
      currentUser = data.session?.user || null;
      supabase.auth.onAuthStateChange(async (_event, session) => {
        currentUser = session?.user || null;
        updateAuthUI();
        await loadProgress();
        await loadCertificates();
        if (activeCourse) { renderUnitNavigation(); renderLesson(); updateCourseProgress(); }
      });
    }
    updateAuthUI();
    await loadProgress();
    await loadCertificates();
    routeFromHash();
    if (!keyReady) console.info('Business Academy A1 lessons are available. Student accounts are waiting for a Supabase Publishable key and schema setup.');
  }

  document.addEventListener('DOMContentLoaded', init);
})();
