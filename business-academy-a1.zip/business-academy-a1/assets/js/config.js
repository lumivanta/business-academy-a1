/* Public browser configuration. Paste the Supabase Publishable key from Dashboard > Settings > API Keys.
   Never place a Secret key or service_role key in this file. */
window.BA1_CONFIG = {
  supabaseUrl: 'https://bimumjqokelykqbjfont.supabase.co',
  supabasePublishableKey: 'PASTE_YOUR_SB_PUBLISHABLE_KEY_HERE'
};
