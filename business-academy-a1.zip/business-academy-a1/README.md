# Business Academy A1

A static, responsive academic-learning website for GitHub Pages, connected to Supabase for optional student accounts, progress records and private PDF completion certificates.

## Included

- Six programmes: Strategic Management, Organisational Behaviour, Corporate Finance, Marketing Strategy, Managerial Economics and Corporate Governance.
- Four advanced units per programme (24 units total).
- Three substantial lesson sections per unit, a visual framework, an applied case, critical limitations, reflection prompts and academic reading links.
- No quizzes, tests, exams, scored assessments or grades.
- Public access to all learning content; sign-in is only needed to save progress and certificates.
- Supabase email/password authentication, learner-owned progress records and private certificate storage.
- A PDF completion certificate after all four units in a programme have been marked complete.

## 1. Configure the Supabase project

The website is already configured with the supplied Project URL:

`https://bimumjqokelykqbjfont.supabase.co`

1. Open the Supabase project dashboard.
2. Open **Settings → API Keys** and copy the **Publishable key** that begins with `sb_publishable_`.
3. Open `assets/js/config.js` and replace `PASTE_YOUR_SB_PUBLISHABLE_KEY_HERE` with that key. Keep the surrounding quotes. A Publishable key is designed for browser applications; never put a Secret key or `service_role` key in this file.
4. In Supabase, open **SQL Editor → New query**. Paste the complete contents of `supabase/schema.sql` and run it. This creates the progress and certificate tables, row-level security policies, a private PDF bucket and a database function that checks the four required unit IDs before issuing a certificate.
5. In **Authentication → URL Configuration**, set the Site URL to the deployed site, for example `https://lumivanta.github.io/business-academy-a1/`, and add that exact URL to the Redirect URLs allow-list. Add your local development URL if you use one.
6. Email/password authentication is used. With email confirmation enabled, new learners must open the confirmation email before signing in. Configure a custom SMTP provider in Supabase before a public launch if the built-in email sending limits are insufficient.

## 2. Publish on GitHub Pages

Upload the contents of this project folder to the root of the repository `lumivanta/business-academy-a1` (not the outer folder itself). The root must contain `index.html`, `README.md`, and the `assets/` and `supabase/` folders.

In GitHub, open **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save. The site URL is:

`https://lumivanta.github.io/business-academy-a1/`

After the GitHub Pages deployment completes, open that URL and test registration, email confirmation, sign-in, marking a unit complete, progress persistence and certificate download.

## 3. Security and certificate notes

- The browser uses only the Supabase Project URL and Publishable key. Never expose a Supabase Secret key or legacy `service_role` key.
- Row Level Security restricts progress rows, certificate records and certificate files to their owner.
- Certificate records are issued through a database function that checks completion of the exact four unit IDs for the requested programme.
- Completion is learner-declared by the **Mark unit as complete** control. There are no exams or verified assessment outcomes.
- Certificates are educational records issued by Business Academy A1. They are not university degrees, accredited academic awards or professional licences.
- PDF creation uses a browser-side library. Certificate records and PDF files are saved in the learner's Supabase account storage.

## Project structure

```text
index.html
README.md
assets/
  css/style.css
  js/app.js
  js/config.js
  js/courses.js
supabase/
  schema.sql
```
