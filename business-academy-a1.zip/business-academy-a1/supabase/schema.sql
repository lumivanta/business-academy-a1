-- Business Academy A1: secure progress and certificate tables for Supabase.
-- Run the complete script in Supabase Dashboard > SQL Editor > New query.

create extension if not exists pgcrypto;

create table if not exists public.lesson_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  program_id text not null,
  lesson_id text not null,
  completed_at timestamptz not null default now(),
  primary key (user_id, lesson_id)
);

create table if not exists public.certificates (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  program_id text not null,
  certificate_number text not null unique,
  file_path text not null,
  issued_at timestamptz not null default now(),
  unique (user_id, program_id)
);

alter table public.lesson_progress enable row level security;
alter table public.certificates enable row level security;

grant usage on schema public to authenticated;
grant select, insert, update on public.lesson_progress to authenticated;
grant select on public.certificates to authenticated;

drop policy if exists "Learners read their own progress" on public.lesson_progress;
create policy "Learners read their own progress" on public.lesson_progress
  for select to authenticated using (auth.uid() = user_id);

drop policy if exists "Learners add their own progress" on public.lesson_progress;
create policy "Learners add their own progress" on public.lesson_progress
  for insert to authenticated with check (auth.uid() = user_id);

drop policy if exists "Learners update their own progress" on public.lesson_progress;
create policy "Learners update their own progress" on public.lesson_progress
  for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "Learners read their own certificates" on public.certificates;
create policy "Learners read their own certificates" on public.certificates
  for select to authenticated using (auth.uid() = user_id);

-- Certificate rows cannot be inserted directly by browser clients. The RPC below
-- checks that the learner has completed the exact four units for the programme.
drop policy if exists "Learners create their own certificates" on public.certificates;

create or replace function public.issue_ba1_certificate(
  p_program_id text,
  p_certificate_number text,
  p_file_path text
) returns public.certificates
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_required text[];
  v_certificate public.certificates;
begin
  if v_user_id is null then
    raise exception 'Authentication required';
  end if;

  case p_program_id
    when 'strategic-management' then v_required := array['strategy-diagnosis','resources-capabilities','competitive-corporate-strategy','strategy-execution'];
    when 'organisational-behaviour' then v_required := array['individuals-and-work-design','motivation-and-performance','teams-and-conflict','leadership-culture-change'];
    when 'corporate-finance' then v_required := array['financial-analysis','time-value-capital-budgeting','risk-return-cost-capital','capital-structure-valuation'];
    when 'marketing-strategy' then v_required := array['market-insight-segmentation','positioning-value-proposition','brand-equity-portfolio','channels-relationships-metrics'];
    when 'managerial-economics' then v_required := array['choice-marginal-analysis','demand-elasticity-pricing','production-costs-scale','market-structures-game-theory'];
    when 'corporate-governance' then v_required := array['governance-architecture-agency','board-effectiveness','risk-controls-assurance','ethics-stakeholders-sustainability'];
    else raise exception 'Unknown learning programme';
  end case;

  if exists (
    select 1 from unnest(v_required) as required_unit(lesson_id)
    where not exists (
      select 1 from public.lesson_progress lp
      where lp.user_id = v_user_id and lp.program_id = p_program_id and lp.lesson_id = required_unit.lesson_id
    )
  ) then
    raise exception 'All four programme units must be marked complete first';
  end if;

  insert into public.certificates(user_id, program_id, certificate_number, file_path)
  values (v_user_id, p_program_id, p_certificate_number, p_file_path)
  on conflict (user_id, program_id) do nothing;

  select * into v_certificate from public.certificates
  where user_id = v_user_id and program_id = p_program_id;
  return v_certificate;
end;
$$;

revoke all on function public.issue_ba1_certificate(text, text, text) from public;
grant execute on function public.issue_ba1_certificate(text, text, text) to authenticated;

-- A private bucket keeps PDF certificates accessible only through authenticated, owner-scoped policies.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('ba1-certificates', 'ba1-certificates', false, 5242880, array['application/pdf'])
on conflict (id) do update set public = false, file_size_limit = 5242880, allowed_mime_types = array['application/pdf'];

drop policy if exists "Learners upload their own certificates" on storage.objects;
create policy "Learners upload their own certificates" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'ba1-certificates' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "Learners read their own certificate files" on storage.objects;
create policy "Learners read their own certificate files" on storage.objects
  for select to authenticated
  using (bucket_id = 'ba1-certificates' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "Learners delete their own certificate files" on storage.objects;
create policy "Learners delete their own certificate files" on storage.objects
  for delete to authenticated
  using (bucket_id = 'ba1-certificates' and (storage.foldername(name))[1] = auth.uid()::text);

-- No public read/write policies are created. Do not disable RLS.
